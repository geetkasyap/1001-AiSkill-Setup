# Skill and tool registry — user shortlist

This is a **routing shortlist**, not proof of installation. Use names/descriptions to choose only relevant capabilities. Always obey higher-priority platform instructions and selected skills. Classification is an integration recommendation, not a guarantee of a uniform installation method.

| Repository | Category | Activate for | State | Avoid / constraint |
|---|---|---|---|---|
| [obra/superpowers](https://github.com/obra/superpowers) | workflow | Relevant structured debugging, TDD, planning, review | **auto-relevant** | Do not run duplicate planning workflow alongside BMAD/GSD/ECC. |
| [addyosmani/agent-skills](https://github.com/addyosmani/agent-skills) | collection | Production engineering for API, frontend, security, performance, testing | **auto-relevant** | Select a single relevant child skill. |
| [morluto/rea](https://github.com/morluto/rea) | tool/specialist | Opaque code, binaries or behavior where normal source tracing is insufficient | **approval-gated** | Authorization and tool review; not default for ordinary bugs. |
| [mattpocock/skills](https://github.com/mattpocock/skills) | collection | Focused engineering decisions, alignment and technical design | **auto-relevant** | Choose individual skill, not whole collection. |
| [alexgreensh/token-optimizer](https://github.com/alexgreensh/token-optimizer) | tool/skill | Diagnosing token/context overhead, compaction workflows | **manual-or-measured** | Core efficiency already always active; extra instrumentation only if useful. |
| [DietrichGebert/ponytail](https://github.com/DietrichGebert/ponytail) | principles/plugin | Minimal safe code, eliminate needless abstraction | **core-principles** | Embed policy principles; installing full plugin/hooks separately requires approval. |
| [JuliusBrussee/caveman](https://github.com/JuliusBrussee/caveman) | tool/skill | Concise agent communication and context optimization | **manual-or-measured** | Not a substitute for essential evidence. |
| [affaan-m/ecc](https://github.com/affaan-m/ecc) | framework/collection | Broader engineering system, agents, conventions and workflows | **manual-only** | Do not make second global controller. |
| [multica-ai/andrej-karpathy-skills](https://github.com/multica-ai/andrej-karpathy-skills) | principles/collection | Evidence-based coding simplicity and deliberate implementation | **core-principles** | Embed essential values, do not load on every turn. |
| [Graphify-Labs/graphify](https://github.com/Graphify-Labs/graphify) | knowledge-graph-tool | Generate/query structural knowledge graph on explicit request | **explicit-only** | No graph generation or repo files without explicit approval. |
| [Panniantong/agent-reach](https://github.com/Panniantong/agent-reach) | research-tool | Third-party web/social/media research integrations | **approval-gated** | Never use account cookies/external services without authorized access. |
| [Egonex-AI/Understand-Anything](https://github.com/Egonex-AI/Understand-Anything) | knowledge-graph-tool | Interactive architectural graph/onboarding for codebases | **explicit-only** | Large scans can be expensive; keep generated data outside Git unless approved. |
| [mvanhorn/last30days-skill](https://github.com/mvanhorn/last30days-skill) | specialized-research | Last-30-days research when explicitly requested | **explicit-only** | Dormant by default. |
| [garrytan/gstack](https://github.com/garrytan/gstack) | framework | Role-based multi-agent workflows and reviews | **manual-only** | Dormant; avoid competing primary workflows. |
| [thedotmack/claude-mem](https://github.com/thedotmack/claude-mem) | memory-tool | Optional session observation and retrieval | **approval-gated** | External recorder/hook review; capture support varies by platform. |
| [headroomlabs-ai/headroom](https://github.com/headroomlabs-ai/headroom) | compression-tool | Measured local output/context compression | **approval-gated** | Proxy/tool installation only after security approval and baseline tests. |
| [gsd-build/get-shit-done](https://github.com/gsd-build/get-shit-done) | framework | Spec-driven project management and implementation | **explicit-only** | Dormant alternative to BMAD; never stack. |
| [bmad-code-org/bmad-method](https://github.com/bmad-code-org/bmad-method) | framework | Major project planning, roles, specifications, delivery structure | **approval-gated** | Recommend with reasons and ask before adopting. |
| [nextlevelbuilder/ui-ux-pro-max-skill](https://github.com/nextlevelbuilder/ui-ux-pro-max-skill) | ui-primary | UI design system and screen-level UX direction | **auto-relevant** | Prefer as one primary for new UI; do not stack competing directors. |
| [vercel-labs/agent-skills](https://github.com/vercel-labs/agent-skills) | ui/web-specialist | Web UI quality and React/Next.js-specific performance guidance | **auto-relevant** | Framework-specific guidance only on matching stack. |
| [leonxlnx/taste-skill](https://github.com/leonxlnx/taste-skill) | ui-primary | Distinctive design direction for sites/apps | **auto-relevant** | Alternative primary to UI UX Pro Max. |
| [Owl-Listener/designer-skills](https://github.com/Owl-Listener/designer-skills) | ui-specialist | Design research, systems and UX evaluations | **auto-relevant** | Select child skill for high-value design review. |
| [codeswithroh/tastemaker](https://github.com/codeswithroh/tastemaker) | ui-primary | Reference-driven art direction and visual aesthetics | **auto-relevant** | Alternative primary; avoid double art-direction. |
| [jakubkrehel/skills](https://github.com/jakubkrehel/skills) | ui-specialist | Typography, color, layout and accessible refinement | **auto-relevant** | Targeted review, not wholesale redesign. |
| [MengTo/Skills](https://github.com/MengTo/Skills) | creative-specialist | Visual/creative implementation and interactive experiences | **auto-relevant** | Use for specifically needed creative interaction. |
| [elayadesign/ai-design-skills](https://github.com/elayadesign/ai-design-skills) | ui-specialist | Landing pages, Figma and design workflow | **auto-relevant** | Only where design workflow fits environment. |
| [ConardLi/garden-skills](https://github.com/ConardLi/garden-skills) | ui/creative-collection | Visual design, motion and creative knowledge | **auto-relevant** | Choose a single relevant child skill. |
| [emilkowalski/skills](https://github.com/emilkowalski/skills) | motion-specialist | High-quality motion and interaction feedback | **auto-relevant** | Motion-specific only; respect reduced-motion accessibility. |
| [bencium/bencium-marketplace](https://github.com/bencium/bencium-marketplace) | ui/collection | Design critique and other specialist workflows | **manual-or-measured** | Verify specific offered skill and maturity before use. |

## Activation definitions

- **core-principles**: Encode the principle into CORE.md; do not automatically load the complete external skill.
- **auto-relevant**: May read a *single installed matching skill* when its trigger applies; no guarantee if unavailable.
- **manual-or-measured**: Activate only on request or when explicitly justified by expected savings and compatibility.
- **explicit-only**: Do not activate unless the user specifically requests the function.
- **manual-only**: Dormant until explicitly requested.
- **approval-gated**: Explain value, costs, scope and permissions; obtain explicit approval before activation/install/runtime effects.

## Default conflict families

- End-to-end project methodology: Superpowers, ECC, BMAD, GSD, gstack. Pick **one primary**.
- Primary UI direction: UI UX Pro Max, Taste Skill, Tastemaker. Pick **one primary** and add focused specialists only.
- Architecture graphs: Graphify **or** Understand Anything. Both are opt-in; neither needs to run during routine bug fixes.
- Memory and compression: Claude-Mem and Headroom are optional tools with security implications, not cost-free skills.
- Routine minimalist coding: core policy covers Ponytail/Karpathy principles; do not run two full prompts on every task.

## Installation check before invoking

1. Confirm the exact skill/tool installed on the current platform; do not assume every GitHub repository is a compatible `SKILL.md`.
2. Check skill metadata only. For a genuine match, read the selected actual `SKILL.md` and its required references.
3. Respect manual/approval states. Never invent commands, capabilities or results.
4. If none is installed, follow core engineering principles using built-in capabilities.

Last reviewed for configuration design: 2026-11-17. See `docs/OFFICIAL-REFERENCES.md` for platform source links.
