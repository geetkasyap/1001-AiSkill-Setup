# Universal AI Engineering System — v1.0

A **ready-to-configure local engineering policy**, not a mass installer of third-party code. Designed for **GitHub Copilot App**, **GitHub Copilot CLI** (optional), **Codex App/CLI**, **Google Antigravity (AGY) App/CLI**, and optionally **Claude Code**.

## Start here (Windows)
1. Read `docs/SETUP-WINDOWS.md` and `docs/SECURITY-AND-LIMITATIONS.md`.
2. Open PowerShell in this extracted folder. Run `./setup/Install-UniversalEngineering.ps1` to **preview** local file destinations; nothing is changed.
3. Review the destinations; if acceptable, run `./setup/Install-UniversalEngineering.ps1 -Apply`. Existing files are **skipped** unless you explicitly use `-ReplaceExisting` (which creates backups).
4. Open GitHub Copilot App settings > Sessions > App instructions; set its global instructions from `CORE.md` **if not already applied**. Other local agents use global files set by the script.
5. Run `./setup/Test-UniversalEngineering.ps1` to check copies and open an agent to test a small task. Only the bundled routing skill is installed; **third-party skills are not installed automatically**.

## What is included
| File/folder | Purpose |
|---|---|
| `CORE.md` | Short mandatory policy: safety, minimal safe change, token efficiency, proportional verification and approvals |
| `SKILL-REGISTRY.md` | All 29 user-supplied GitHub repositories, purpose and trigger state |
| `KNOWLEDGE-POLICY.md` | Optional external-to-Git knowledge approach and freshness checks |
| `UI-QUALITY.md` | UI aesthetic and interaction quality rubric |
| `TASK-ROUTING.md` | Adaptive tasks, skill overlap, stop conditions |
| `skills/engineering-workflow-router/` | One real, self-contained optional orchestrator skill; specialist routing only |
| `setup/` | Preview-first PowerShell setup, knowledge-folder creation, read-only setup checks and skill inventory |
| `templates/` | Knowledge and handoff templates, used only with your permission |
| `docs/` | Setup, legacy-protocol mapping, skill installation, security, cost checks and platform references |
| `examples/` | Short prompts to confirm setup and exercise routes |

## Design decisions
- The **core policy is copied once** into each supported local agent's personal instructions. It is not pasted at the start of every session.
- Codex and Copilot can share one personal skill location (`~/.agents/skills/`). AGY needs its own compatible skill directory, so the bundled skill is copied there as well.
- The registry lists **available candidates**; a registry entry does not imply installation, compatibility or permission.
- Dormant/manual skills must not be auto-invoked simply because they are installed. If a host requires more enforcement than instructions provide, enable its supported manual-invocation settings after reviewing that skill.
- Meaningful knowledge updates happen **only after consent**, outside the Git repository. The script does not create any project-specific knowledge by default.
- Policies affect agent behavior but **are not a substitute** for platform-level permissions, sandbox settings or corporate data safeguards.

## Updating later
Edit `CORE.md` and rerun setup with `-Apply -ReplaceExisting` after reviewing backups and local changes. Update `SKILL-REGISTRY.md` separately; it is a human-facing catalog and the router skill packages a generated snapshot in `references/skill-registry.md`. When you change the catalog, sync the copy in the skill and redeploy it. See setup guide.

Verified against public documentation on **2026-11-17**. Product capabilities may change.
