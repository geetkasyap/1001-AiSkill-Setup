---
name: engineering-workflow-router
description: Select a minimal set of compatible engineering or UI agent skills, resolve overlapping workflows, and plan proportionate work. Use when a coding task spans multiple systems or skill domains, when several installed skills might conflict, when deciding whether to use a major development framework, or when reviewing skill activation and token/cost tradeoffs. Do not invoke for routine one-file fixes or simple questions.
---

# Engineering workflow router

Select **one coherent workflow**; do not become a second framework. Respect active global, organization, user, repository and security instructions, especially permission gates.

1. Classify the task: ordinary fix, cross-layer feature, large architecture, UI concept, risk-critical logic, opaque behavior, opt-in knowledge graph, research.
2. Inspect **available** skill metadata/installed locations only. If skill-selection details matter, consult `references/skill-registry.md` for the original shortlist and gates; that list is NOT an installed-skill inventory.
3. Decide whether specialist skill instructions genuinely add more value than their context and tool cost. For a simple task, use the base agent without further skill activation.
4. Select at most one primary method (Superpowers OR BMAD OR GSD OR ECC OR gstack), with optional complementary stack, accessibility, security or motion specialist when justified. This is a heuristic; mandatory skill/platform rules override it.
5. For UI, preserve existing application design systems, minimize unnecessary clicks/scrolling and visual clutter; demand purposeful, polished design rather than generic AI styles. Choose one primary UI direction.
6. Do not auto-run dormant/explicit-only skills. Major frameworks, external installers, memory recorders, proxies, unauthorized network access, graph generation and other consequential tools require permission.
7. Read the selected skill's **actual SKILL.md** through the host's supported mechanism. Follow its mandatory instructions. Never claim a skill ran when not installed or not invoked.
8. For complex changes, deliver a concise implementation plan, risks, verification and tradeoffs; **wait for approval before editing code**. For routine scoped changes, implement directly and verify proportionately.
9. After meaningful completed work, offer to save verified reusable notes locally outside Git; **do not write them until approved**.

Output when selection itself is discussed: `Task type | Primary workflow | Optional specialist | Why | Approval required`. Otherwise, don't add a skill-selection report unless important to execution.
