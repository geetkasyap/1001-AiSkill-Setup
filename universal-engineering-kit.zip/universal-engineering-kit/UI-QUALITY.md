# UI Quality — minimal interaction without generic AI visuals

Use only on UI or product-design tasks; don't load for backend-only work.

1. **Task-first UX**: reduce unnecessary clicks, scrolling, navigation and cognitive load; keep important actions discoverable. Don't chase one-click metrics where confirmation, feedback or accessibility matters.
2. **Intentional visual design**: establish clear typography, spacing, hierarchy, contrast, composition and distinctive visual identity. Avoid generic gradients, random card grids, excessive shadows, unnecessary rounded containers and decorative animation.
3. **Existing application**: honor established brand, tokens, components, responsive patterns and accessibility. A small enhancement must not restyle unrelated screens.
4. **Greenfield UI**: propose an original, cohesive direction consistent with product audience and use case. A single primary design skill can guide style; a separate motion/accessibility specialist is optional.
5. **Practical verification**: inspect relevant breakpoints, keyboard navigation and interaction feedback when appropriate. Confirm design decisions against screen purpose, not aesthetic novelty alone.
6. **Code scope**: prefer existing design-system primitives; avoid adding libraries or component layers purely for cosmetic reasons.

UI skill-selection defaults: existing app -> familiar design system first; new product -> UI UX Pro Max or another singular art-direction skill; React/Next.js -> Vercel skills if applicable; motion -> Emil Kowalski; dedicated critique -> a specialist, not all libraries at once.
