# Short optional starter prompts — not required each session

The global policy should already be loaded. These are for quickly testing setup or giving unusual tasks explicit direction; do not paste the full configuration files into each chat.

**Check configuration (read-only):**
> Without changing files, summarize the global engineering instructions you received and list available engineering-workflow-router skill metadata. Say which local knowledge folder you can actually access. Do not load all installed skills.

**Small bug:**
> Fix this validation defect in `<path>`. Reproduce/trace only the relevant path, make the smallest correct edit, run focused verification, and report the changed files and evidence. Do not use a full planning framework.

**Cross-layer feature (approval required):**
> Analyze how to implement `<feature>` across `<stack>`. Identify the affected paths, options, risks and minimal verification. Do not modify code until I approve the implementation plan. Select only relevant specialist skills.

**Large application (framework is opt-in):**
> Discover requirements for `<application>`, compare a lightweight plan with BMAD, and recommend one with token/cost tradeoffs. Do not install tools or begin implementation without my approval.

**UI enhancement:**
> Improve `<screen>` within our existing design system. Minimize unnecessary interactions and scrolling, avoid generic AI-looking UI, and present a distinctive but consistent concept. Select one primary UI skill; do not change code until the requested design is approved if this is a complex redesign.

**Knowledge after meaningful task:**
> Summarize only the verified reusable findings. Ask before writing any project knowledge outside Git. Include source anchors, tests and freshness information; do not automatically build a graph.
