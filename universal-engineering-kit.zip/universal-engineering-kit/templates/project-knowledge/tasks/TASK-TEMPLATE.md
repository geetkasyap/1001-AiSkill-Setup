# Task: [ID / meaningful label]

- Last validated: {{DATE}}
- Repo: `{{PROJECT_PATH}}`
- Branch/commit: [record exact value if available]
- Status: proposed / approved / in-progress / verified / blocked
- Source anchors: [paths/symbols only, avoid sensitive source dumps]

## Objective and acceptance criteria
[short]

## What changed
[files and behavior; distinguish planned vs completed]

## Verification actually executed
[command + result; never mark unexecuted checks as passed]

## Decisions / remaining risks
[status: verified / user-stated / inferred / unresolved]

## Next session
[only actionable context]
