# Decisions — {{PROJECT_ID}}

Only record user-approved, durable decisions. Do not infer approval from a proposed plan.

| Date | Decision | Reason | Alternatives | Approved by/context | Revisit when |
|---|---|---|---|---|---|
