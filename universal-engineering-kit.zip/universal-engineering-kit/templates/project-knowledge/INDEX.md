# {{PROJECT_ID}} — knowledge index

- Repository path: `{{PROJECT_PATH}}`
- Created: {{DATE}}
- Knowledge status: **not yet researched**
- Source of truth: current repo source and verified test results
- Sensitivity/allowed use: [fill in; do not include credentials or customer identifiers]
- Last verified branch/commit: [unknown until checked]

## Navigation
- `architecture.md` — only verified structural facts
- `decisions.md` — user-approved decisions
- `tasks/` — meaningful tasks, as approved

## Load rule
New sessions: read this index, then only related notes. Revalidate changed source. Ask before updating this directory.
