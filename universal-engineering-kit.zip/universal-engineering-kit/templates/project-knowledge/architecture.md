# Architecture — {{PROJECT_ID}}

> Initial status: unverified template. Add findings after approved onboarding only.

| Component/path | Responsibility | Source evidence | Fact status | Validated on |
|---|---|---|---|---|
| [pending] | [pending] | [source path/line or command] | unresolved | {{DATE}} |

## Integration boundaries
[Only verified facts with source anchors]

## Known unknowns
[Explicit gaps; do not invent architecture]
