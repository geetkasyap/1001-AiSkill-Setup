# Adaptive task and skill router

Only read this file when routing needs more detail than `CORE.md`. A tiny edit needs no skills merely to justify being tiny.

## Five decisions
1. Classify: consultation / small change / medium integrated task / complex feature or architecture / risk-sensitive operation / UI-design task / specialized investigation / graph or research.
2. Check whether available tools/skills are actually installed and compatible. Metadata first. Never assume GitHub repository equals an installed agent skill.
3. Pick **one primary workflow** for the task. Do not combine Superpowers, ECC, GSD, BMAD, and gstack as overlapping master workflows.
4. Add a specialist only if it provides complementary expertise and its expected value exceeds context/tool overhead. One primary plus up to two specialists is a **soft heuristic**, not a cap on necessary work.
5. Honor manual-only and approval gates. Read selected `SKILL.md` and required references; do not ignore its mandatory directions.

## Decision matrix
| Task | Default | Specialist eligibility | Approval |
|---|---|---|---|
| Text or one-line logic change | Focused inspection + diff/check | None unless exact skill required | Not for safe scoped edit |
| Typical backend/API or frontend bug | Trace callers, establish root cause | Relevant debugging or stack-specific skill | Ask if scope/architecture expands |
| High-risk financial/security/concurrency/data bug | Reproduce, trace, focused regression | Debugging + risk-domain specialist | Ask before significant implementation |
| Cross-layer feature / architecture | Plan stages and acceptance tests | One structured workflow, optional production review | **Before implementing** |
| New large application | Discover requirements and design options | Propose BMAD or alternative, not both | **Before adopting framework and implementing** |
| Existing UI enhancement | Existing design system is authority | One UI quality skill, optional accessibility/motion | Ask for major redesign |
| New UI/creative concept | Clarify desired function and visual identity | One primary design direction, complementary review | Design concept may proceed; implementation approval if complex |
| Opaque binary/runtime behavior | Confirm ordinary source inspection inadequate | REA, authorized only | Ask if invasive tools are needed |
| Knowledge graph | No graph by default | Graphify OR Understand Anything | Explicit user request + data/tool approval |
| Research or last-30-days | Normal research only if needed | Agent-Reach conditional, Last30Days explicit only | Ask before auth/cookie/third-party tooling |

## Stop rules
- Stop investigation when cause/implementation is supported by enough evidence.
- Stop skill evaluation after selecting an adequate workflow; do not keep searching for an ideal skill.
- Stop adding tests when risk-based confidence is established; never skip meaningful tests just to save tokens.
- No unattended background loops. No auto installation, skill hooks, memory capture, or external proxies.

## Conflicts and fallbacks
- Precedence: system/org/security > repository instructions > applicable activated skill mandatory steps > user preferences where compatible > convenience.
- If relevant skills disagree, choose a single primary workflow and state any material conflict; do not run both redundant processes.
- If no skill is available, complete the task with standard capabilities and disclose the limitation if it materially affects quality.
- If a cloud agent cannot read local notes, work from available source and provided attachments; don't hallucinate them.
