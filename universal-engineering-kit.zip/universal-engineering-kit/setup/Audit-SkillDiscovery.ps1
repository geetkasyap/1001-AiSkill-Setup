# Read-only metadata inventory. Lists direct child SKILL.md manifests without loading all bodies.
[CmdletBinding()]
param()
$homeDir = [Environment]::GetFolderPath('UserProfile')
$roots = [ordered]@{
    'Codex + Copilot shared' = Join-Path $homeDir '.agents/skills'
    'Copilot personal'      = Join-Path $homeDir '.copilot/skills'
    'AGY App + CLI shared'  = Join-Path $homeDir '.gemini/config/skills'
    'AGY CLI additional'   = Join-Path $homeDir '.gemini/antigravity-cli/skills'
    'Claude optional'      = Join-Path $homeDir '.claude/skills'
}
$seen = @{}
foreach ($name in $roots.Keys) {
    $root = $roots[$name]
    Write-Host "`n$name  [$root]"
    if (-not (Test-Path -LiteralPath $root -PathType Container)) { Write-Host '  (directory not found)'; continue }
    $found = 0
    foreach ($skillDir in @(Get-ChildItem -LiteralPath $root -Directory)) {
        $manifest = Join-Path $skillDir.FullName 'SKILL.md'
        if (Test-Path -LiteralPath $manifest -PathType Leaf) {
            Write-Host "  $($skillDir.Name)"
            $found++
            if (-not $seen.ContainsKey($skillDir.Name)) { $seen[$skillDir.Name] = @() }
            $seen[$skillDir.Name] += $name
        }
    }
    if ($found -eq 0) { Write-Host '  (no direct skill manifests)' }
}
Write-Host "`nNote: This is not a complete platform plugin inventory; app-installed plugins may live elsewhere."
Write-Host 'Duplicate skill names across platforms are often intentional. Within one platform, review project-level overrides for conflicts.'
Write-Host 'No skills were invoked or installed.'
