# Read-only local diagnostic: no code edits, network access, or skill installation.
[CmdletBinding()]
param([switch]$IncludeClaude)
$ErrorActionPreference = 'Stop'
$homeDir = [Environment]::GetFolderPath('UserProfile')
$base = Join-Path $homeDir 'AI-Engineering'
$codexHome = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $homeDir '.codex' }
$copilotHome = if ($env:COPILOT_HOME) { $env:COPILOT_HOME } else { Join-Path $homeDir '.copilot' }
$core = Join-Path $base 'CORE.md'
Write-Host 'Read-only instruction and skill verification:'
if (-not (Test-Path -LiteralPath $core -PathType Leaf)) {
    Write-Warning "Missing $core - run setup -Apply first."
    exit 1
}
$expected = (Get-FileHash -LiteralPath $core -Algorithm SHA256).Hash
$files = @(
    (Join-Path $codexHome 'AGENTS.md'),
    (Join-Path $copilotHome 'copilot-instructions.md'),
    (Join-Path $homeDir '.gemini/AGENTS.md')
)
if ($IncludeClaude) { $files += Join-Path $homeDir '.claude/CLAUDE.md' }
foreach ($f in $files) {
    if (-not (Test-Path -LiteralPath $f -PathType Leaf)) { Write-Warning "MISSING: $f"; continue }
    $actual = (Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash
    if ($actual -eq $expected) { Write-Host "OK instruction: $f" }
    else { Write-Warning "DIFFERENT: $f (review policy merge or rerun setup after backup)" }
}
$skills = @(
    (Join-Path $homeDir '.agents/skills/engineering-workflow-router/SKILL.md'),
    (Join-Path $homeDir '.gemini/config/skills/engineering-workflow-router/SKILL.md')
)
if ($IncludeClaude) { $skills += Join-Path $homeDir '.claude/skills/engineering-workflow-router/SKILL.md' }
foreach ($f in $skills) {
    if (Test-Path -LiteralPath $f -PathType Leaf) { Write-Host "OK skill: $f" }
    else { Write-Warning "MISSING skill: $f" }
}
Write-Host 'This checks on-disk files, not app-side discovery or cloud runtime availability.'
