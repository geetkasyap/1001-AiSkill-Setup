# Windows PowerShell 5.1+ / PowerShell 7+
# Preview-only unless -Apply is supplied. No network, package installation, Git writes or execution-policy changes.
[CmdletBinding()]
param(
    [switch]$Apply,
    [switch]$ReplaceExisting,
    [switch]$IncludeClaude
)
$ErrorActionPreference = 'Stop'
$package = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$homeDir = [Environment]::GetFolderPath('UserProfile')
$managedHome = Join-Path $homeDir 'AI-Engineering'
$codexHome = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $homeDir '.codex' }
$copilotHome = if ($env:COPILOT_HOME) { $env:COPILOT_HOME } else { Join-Path $homeDir '.copilot' }
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$stats = @{ Planned = 0; Created = 0; Skipped = 0; Same = 0; Replaced = 0 }

function Copy-SafeFile {
    param([Parameter(Mandatory=$true)][string]$Source,[Parameter(Mandatory=$true)][string]$Target)
    if (-not (Test-Path -LiteralPath $Source -PathType Leaf)) { throw "Source file not found: $Source" }
    if (Test-Path -LiteralPath $Target -PathType Leaf) {
        $srcHash = (Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash
        $dstHash = (Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash
        if ($srcHash -eq $dstHash) { Write-Host "SAME  $Target"; $stats.Same++; return }
        if (-not $ReplaceExisting) { Write-Warning "SKIP existing different file (manual merge or use -ReplaceExisting): $Target"; $stats.Skipped++; return }
    }
    if (-not $Apply) { Write-Host "PLAN  $Target"; $stats.Planned++; return }
    $parent = Split-Path -Parent $Target
    if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    if (Test-Path -LiteralPath $Target -PathType Leaf) {
        $backup = "$Target.backup-$timestamp"
        Copy-Item -LiteralPath $Target -Destination $backup -ErrorAction Stop
        Copy-Item -LiteralPath $Source -Destination $Target -Force -ErrorAction Stop
        Write-Host "REPLACED $Target (backup: $backup)"; $stats.Replaced++
    } else {
        Copy-Item -LiteralPath $Source -Destination $Target -ErrorAction Stop
        Write-Host "CREATED  $Target"; $stats.Created++
    }
}
function Copy-SafeTree {
    param([Parameter(Mandatory=$true)][string]$SourceDir,[Parameter(Mandatory=$true)][string]$TargetDir)
    if (-not (Test-Path -LiteralPath $SourceDir -PathType Container)) { throw "Missing directory: $SourceDir" }
    $srcRoot = (Resolve-Path -LiteralPath $SourceDir).Path.TrimEnd([IO.Path]::DirectorySeparatorChar)
    Get-ChildItem -LiteralPath $SourceDir -File -Recurse | ForEach-Object {
        $relative = $_.FullName.Substring($srcRoot.Length).TrimStart([char[]]@('\','/'))
        Copy-SafeFile -Source $_.FullName -Target (Join-Path $TargetDir $relative)
    }
}

Write-Host "Universal AI Engineering System - $(if ($Apply) {'APPLY'} else {'PREVIEW ONLY'})"
Write-Host "Source: $package"
Write-Host "Managed local directory: $managedHome"
Write-Host 'No external software or third-party skills will be installed.'

# Managed reference files remain outside source repositories.
foreach ($name in @('README.md','CORE.md','SKILL-REGISTRY.md','TASK-ROUTING.md','KNOWLEDGE-POLICY.md','UI-QUALITY.md','registry.json')) {
    Copy-SafeFile -Source (Join-Path $package $name) -Target (Join-Path $managedHome $name)
}
Copy-SafeTree -SourceDir (Join-Path $package 'docs') -TargetDir (Join-Path $managedHome 'docs')

# Codex App + CLI; Copilot CLI (Copilot App's App instructions are set separately in UI).
if (Test-Path -LiteralPath (Join-Path $codexHome 'AGENTS.override.md')) {
    Write-Warning 'Codex AGENTS.override.md is present; it may take precedence over installed AGENTS.md. Review manually.'
}
Copy-SafeFile -Source (Join-Path $package 'CORE.md') -Target (Join-Path $codexHome 'AGENTS.md')
Copy-SafeFile -Source (Join-Path $package 'CORE.md') -Target (Join-Path $copilotHome 'copilot-instructions.md')
# Google Antigravity App + CLI: current unified global rules location.
foreach ($alternate in @('.gemini/GEMINI.md','.gemini/config/AGENTS.md','.gemini/config/GEMINI.md')) {
    if (Test-Path -LiteralPath (Join-Path $homeDir $alternate)) { Write-Warning "An additional AGY global rule file exists ($alternate); review for duplicate/conflicting instructions." }
}
Copy-SafeFile -Source (Join-Path $package 'CORE.md') -Target (Join-Path $homeDir '.gemini/AGENTS.md')

# Two skill roots are needed to cover Codex/Copilot and Antigravity on the local machine.
$routerSource = Join-Path $package 'skills/engineering-workflow-router'
Copy-SafeTree -SourceDir $routerSource -TargetDir (Join-Path $homeDir '.agents/skills/engineering-workflow-router')
Copy-SafeTree -SourceDir $routerSource -TargetDir (Join-Path $homeDir '.gemini/config/skills/engineering-workflow-router')
if ($IncludeClaude) {
    Copy-SafeFile -Source (Join-Path $package 'CORE.md') -Target (Join-Path $homeDir '.claude/CLAUDE.md')
    Copy-SafeTree -SourceDir $routerSource -TargetDir (Join-Path $homeDir '.claude/skills/engineering-workflow-router')
}

Write-Host "Summary: planned=$($stats.Planned), created=$($stats.Created), replaced=$($stats.Replaced), existing-same=$($stats.Same), skipped=$($stats.Skipped)"
if (-not $Apply) { Write-Host 'No changes made. Rerun with -Apply after reviewing the planned destinations.' }
Write-Host 'GitHub Copilot App: copy CORE.md into Settings > Sessions > App instructions if not already configured.'
Write-Host 'Open a NEW agent session to test the installed policy and skill discovery.'
