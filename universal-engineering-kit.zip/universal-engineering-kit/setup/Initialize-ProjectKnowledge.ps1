# Opt-in scaffolding ONLY; never run automatically after a task.
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$ProjectPath,
    [Parameter(Mandatory=$true)][string]$ProjectId,
    [string]$KnowledgeDirectory,
    [switch]$Apply
)
$ErrorActionPreference = 'Stop'
if ($ProjectId -notmatch '^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$') { throw 'ProjectId must contain 1-64 letters/digits/underscore/hyphen, starting with a letter/digit.' }
if (-not (Test-Path -LiteralPath $ProjectPath -PathType Container)) { throw "Project path not found: $ProjectPath" }
$repo = [IO.Path]::GetFullPath((Resolve-Path -LiteralPath $ProjectPath).Path).TrimEnd([char[]]@('\','/'))
$homeDir = [Environment]::GetFolderPath('UserProfile')
$defaultRoot = Join-Path (Join-Path $homeDir 'AI-Engineering') 'projects'
$target = if ($KnowledgeDirectory) { [IO.Path]::GetFullPath($KnowledgeDirectory) } else { Join-Path $defaultRoot $ProjectId }
$target = [IO.Path]::GetFullPath($target).TrimEnd([char[]]@('\','/'))
$cmp = [StringComparison]::OrdinalIgnoreCase
if ($target.Equals($repo,$cmp) -or $target.StartsWith(($repo+[IO.Path]::DirectorySeparatorChar),$cmp)) {
    throw 'Knowledge destination must be outside the project working tree.'
}
$package = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$mapping = Join-Path (Join-Path $homeDir 'AI-Engineering') 'PROJECT-INDEX.md'
if (Test-Path -LiteralPath $mapping -PathType Leaf) {
    $previousLines = @(Get-Content -LiteralPath $mapping -Encoding UTF8)
    $identifier = '| `' + $ProjectId + '` |'
    foreach ($line in $previousLines) {
        if ($line.Contains($identifier) -and ((-not $line.Contains($repo)) -or (-not $line.Contains($target)))) {
            throw "ProjectId already points to a different repository or knowledge folder in $mapping. Pick another ProjectId or review mapping manually."
        }
    }
}
$existingIndex = Join-Path $target 'INDEX.md'
if (Test-Path -LiteralPath $existingIndex -PathType Leaf) {
    $existingText = Get-Content -LiteralPath $existingIndex -Raw -Encoding UTF8
    if (-not $existingText.Contains($repo)) { throw "Knowledge folder already has INDEX.md that does not identify this project path. Stop to avoid cross-project mixing: $existingIndex" }
}
Write-Host "Repository: $repo"
Write-Host "Proposed knowledge location: $target"
Write-Host "Mode: $(if ($Apply) {'APPLY'} else {'PREVIEW ONLY'})"
$templates = @('INDEX.md','architecture.md','decisions.md','tasks/TASK-TEMPLATE.md')
foreach ($name in $templates) {
    $src = Join-Path (Join-Path $package 'templates/project-knowledge') $name
    $dest = Join-Path $target $name
    if (Test-Path -LiteralPath $dest) { Write-Host "SKIP existing: $dest"; continue }
    if (-not $Apply) { Write-Host "PLAN: $dest"; continue }
    $parent = Split-Path -Parent $dest
    if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    $body = (Get-Content -LiteralPath $src -Raw -Encoding UTF8).Replace('{{PROJECT_ID}}',$ProjectId).Replace('{{PROJECT_PATH}}',$repo).Replace('{{DATE}}',(Get-Date -Format 'yyyy-MM-dd'))
    [IO.File]::WriteAllText($dest,$body,(New-Object System.Text.UTF8Encoding($false)))
    Write-Host "CREATED: $dest"
}
if (-not $Apply) { Write-Host 'No files created. Rerun with -Apply only if you approve knowledge scaffolding.' }

# Register only an approved scaffold in the local directory so other sessions can find it.
if ($Apply) {
    $mappingParent = Split-Path -Parent $mapping
    if (-not (Test-Path -LiteralPath $mappingParent)) { New-Item -ItemType Directory -Path $mappingParent -Force | Out-Null }
    $marker = ('`' + $ProjectId + '`')
    if (-not (Test-Path -LiteralPath $mapping)) {
        $intro = "# Project knowledge map (local, outside Git)`r`n`r`n| Project ID | Repository | Knowledge directory |`r`n|---|---|---|`r`n"
        [IO.File]::WriteAllText($mapping,$intro,(New-Object System.Text.UTF8Encoding($false)))
    }
    $mapText = Get-Content -LiteralPath $mapping -Raw -Encoding UTF8
    if ($mapText -notmatch ([regex]::Escape('| ' + $marker + ' |'))) {
        Add-Content -LiteralPath $mapping -Value ('| ' + $marker + ' | `' + $repo + '` | `' + $target + '` |') -Encoding UTF8
        Write-Host "REGISTERED project in $mapping"
    } else {
        Write-Host "ProjectId may already be registered: check $mapping for the correct repository path."
    }
} else {
    Write-Host "PLAN: after approved scaffold, register project in $mapping"
}
