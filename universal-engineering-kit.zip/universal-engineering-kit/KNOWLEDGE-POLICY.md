# Knowledge outside Git — consent-first policy

## Purpose
Avoid repeatedly rediscovering verified architecture and prior task decisions across independent sessions without turning session logs into an uncontrolled knowledge dump.

## Storage
Default: `~/AI-Engineering/projects/<project-id>/` with distinct IDs per project. You may explicitly choose another local folder outside the project Git working tree. Do **not** create an `AGENTS.md` or knowledge document inside an enterprise repo simply to make local memory visible.

An agent may read existing **authorized** local notes when available. It must **ask before creating or changing** any persistent knowledge records following a meaningful completed task. Do not create files for small fixes unless the user specifically asks. A user-approved initial onboarding may create a baseline only after confirming scope and cost.

## Minimal structure (create on approval)
- `INDEX.md`: project alias, repo path, owner/sensitivity, what notes exist, last verification.
- `architecture.md`: verified boundaries, call paths and exact source anchors; not an entire code dump.
- `decisions.md`: decision, alternatives, rationale, approval source/date, validity.
- `tasks/<task-id>.md`: objective, attempted and completed changes, files, checks, caveats, next actions.

Optional: `handoff.md` after a long task, or `ui-guidelines.md` when useful. Avoid auto-generated sprawling knowledge for every task.

## Fact requirements
Each durable claim needs a **status**: verified / user-stated / inferred / unresolved; source path or command, relevant branch/commit or version when known, and last-validated date. Never promote a hypothesis to fact simply because it was saved. Treat source code and current test results as more authoritative for current behavior than old knowledge.

## Session startup
If accessible, first locate the project in `~/AI-Engineering/PROJECT-INDEX.md` (created only with approved onboarding); then read only `INDEX.md`, then the relevant feature/task entry. Do not read the entire knowledge tree. If notes conflict with code, investigate relevant code and correct the record **only with approval**.

## Privacy
Never persist access tokens, credentials, customer records, private email content, confidential source excerpts, secrets, personal identifying data, or unapproved telemetry. Company/client information may require stricter rules or disallow external memory tools entirely. Local storage does not automatically make a tool compliant.

## Proactive prompt after a meaningful task
"I found reusable project knowledge about <topic>. Save a short verified checkpoint in your local knowledge folder (outside Git)?" Offer concise scope; a declined save means no write.
