# Installing third-party skills responsibly

The main registry lists **all 29 repositories** that you supplied, but these are **not 29 guaranteed installable agent skills**. They include prompt principles, skill collections, full frameworks, memory tools, compressed-context proxies and knowledge-graph applications.

## Approach

1. **Start without external installations.** The core policy already implements minimal safe changes, context efficiency and proportional verification.
2. For an approved specialist, visit the exact repository link in `SKILL-REGISTRY.md`. Check the latest README for the host, installation steps, real `SKILL.md` paths, dependencies, hooks, scripts and license. Do not copy an entire GitHub project into a skills directory merely because it has an AI-related name.
3. Inspect any scripts, hooks, plugins, external calls, browser cookie access, telemetry and memory capture **before** installation; seek organizational approval on work devices.
4. Install **only selected individual skills** where the specific host discovers them. For Codex+Copilot personal skills, a documented shared location is `%USERPROFILE%\.agents\skills\<skill-name>\SKILL.md`. For AGY App+CLI, use `%USERPROFILE%\.gemini\config\skills\<skill-name>\SKILL.md`. Some frameworks require their own installer and cannot be represented by copying one SKILL.md.
5. Never silently enable active hooks, auto-recorders, network proxies or model routing for all projects. For high-risk tools, verify host support and consider a separate personal profile before any work/client installation.

## Recommended roll-out sequence

**Phase 1 — zero third-party dependencies:** Use the global CORE and bundled router skill. Benchmark a tiny bug fix, an API integration task and a UI task.

**Phase 2 — curated engineering workflows:** Add only specific Superpowers, Addy Osmani or Matt Pocock child skills you find materially useful. Treat Ponytail and Karpathy style as already represented by CORE; install Ponytail's full plugin/hook only if you specifically want its additional commands and accept its runtime behavior.

**Phase 3 — UI:** Start with one primary visual-direction skill (UI UX Pro Max *or* Taste Skill *or* Tastemaker). Add a focused accessibility or motion skill when needed. Never auto-load all eleven libraries.

**Phase 4 — specialized capabilities, opt-in:** Graphify or Understand Anything only when you ask for a graph. REA when ordinary debugging is insufficient. Last30Days only by explicit request. Agent-Reach only with permitted access. BMAD only after approval; GSD/gstack remain dormant.

**Phase 5 — advanced memory/cost tools, measured:** Evaluate Claude-Mem or Headroom only after security review and representative before/after measurements. Their hooks/proxies may impact multiple agents and may be unsuitable for enterprise code.

## Skill loading principles

- The model normally sees **skill metadata** before selecting a skill, then reads its full `SKILL.md` as needed. This is why short descriptions and correct install paths are more valuable than always injecting full documents.
- A local catalog controls policy but doesn't alter the tool's native skill invoker. A skill marked `manual-only` in the registry should ideally also be configured with any host-supported manual-only mechanism; if unavailable, do not claim hard enforcement.
- If a repository lacks a compatible skill, it may still be useful as a manually consulted resource or a tool under its documented installation method. Do not invent a fictitious skill command.

## Particular cautions

- **Graphify:** project graph generation is explicit-only. Its official Python package name is documented as `graphifyy` (two y's); avoid similarly named packages if eventually installing.
- **Understand Anything:** running its large initial architecture pipeline may consume substantial context. It may write `.ua/` by default, so deliberately choose an approved outside-Git workflow if supported, rather than silently modifying the project.
- **Claude-Mem:** integration availability and capture-vs-retrieval support vary by host. Work/client data recording requires separate approval.
- **Headroom:** compression can remove context important to debugging even if results are reversible. Evaluate on representative cases before enabling a wrapper/proxy globally.
- **Ponytail:** its full plugin includes additional command/hook behaviors beyond the lightweight core principles. Only install through official, reviewed methods.

## Future maintenance

Once a quarter or when switching agent versions, review any installed skill's upstream version, trigger behavior, duplicated commands, extra dependencies and security impact. Removing a skill from the agent does not necessarily remove hooks or memory data; follow its own uninstallation instructions.
