# Security, trust and limitations

1. **This kit never installs third-party skills/tools, network services, hooks or agents.** It installs a local instruction bundle and one instruction-only routing skill only when you run the setup script with `-Apply`.
2. For company/customer systems, obtain approval before installing or running external plugins, MCP servers, memory recorders, proxies, browser-cookie integrations, telemetry, or downloading proprietary source to unmanaged services. The kit does not certify any third-party repository as safe.
3. Global prompt instructions are advisory behavior, not enforcement. Configure actual permissions/sandbox/trust separately in every platform; enterprise policy overrides user settings.
4. Never paste secrets, tokens or sensitive logs into knowledge files. Maintain separate private and enterprise knowledge roots if your company permits any local notes. Do not share private client notes between projects.
5. This kit does not imply all 29 listed GitHub repositories are skill folders. Many are frameworks, tools, plugins or collections. Verify a real `SKILL.md`, install mechanism, license, supported host and dependencies first.
6. Global availability is **per machine/runtime**. Codex Cloud, Copilot cloud and remote Antigravity jobs may not access local instructions or knowledge directories. Copying local instructions does not configure a cloud workspace.
7. There is no guarantee of tokens saved. Measure input tokens, tool calls, elapsed time, retries and correctness on representative tasks before adding memory/compression proxies.
8. Setup uses skip-if-exists semantics by default. `-ReplaceExisting` backs up files before replacement. Inspect app-local instructions to avoid duplicates with already-configured policies.
9. Historical memory may be stale. Project source and tests are authoritative for current implementation behavior.
10. Scripts are intended for **Windows PowerShell 5.1+ / PowerShell 7+**. They have not been executed on your machine; read-only structural checks were performed in the authoring environment. Follow workplace execution policies; don't bypass restrictions.
