# How this replaces the previous Universal Copilot Engineering Protocol

The earlier 16-section protocol was a solid engineering baseline but too large to inject repeatedly, and it named repositories without distinguishing skills from tools/frameworks. The design here retains the important behaviors while moving specialist decisions out of always-on context.

| Previous section | New location | Retention / improvement |
|---|---|---|
| 1. Skill orchestration | `CORE.md`, `SKILL-REGISTRY.md`, router skill | Explicit modes, conflict families; actual installed-skill discovery required |
| 2. Session initialization | `CORE.md` | Cheap startup; full onboarding only once for large long-lived repos and with approval |
| 3. Task classification | `TASK-ROUTING.md` | Simple/medium/complex/risk/UI/opaque/graph branches |
| 4. Codebase investigation | `CORE.md` | Search known symbols, expand only on evidence |
| 5. Root-cause debugging | `CORE.md`, `TASK-ROUTING.md` | Focused trace and evidence before fixes |
| 6. Minimal change | `CORE.md` | Ponytail/Karpathy principles are always on without duplicate full skill loading |
| 7. Planning | `CORE.md`, `TASK-ROUTING.md` | Complex tasks require plan and approval **before implementation** |
| 8. Implementation discipline | `CORE.md` | Preserve conventions, no speculative scope |
| 9. Quality gates | `CORE.md`, `docs/COST-AND-QUALITY-TESTS.md` | Checks proportional to actual risk |
| 10. Token and credit optimization | `CORE.md`, test guide | Optimize **end-to-end** cost including rework; optional measured compression |
| 11. Git safety | `CORE.md` | No unsolicited commit/push/branch/worktree/destructive operations |
| 12. Verification | `CORE.md` | Never claim unexecuted tests passed |
| 13. Final response | `CORE.md` | Concise changed / verified / risks |
| 14. Long session context | `KNOWLEDGE-POLICY.md`, templates | Consent-first durable knowledge outside Git, with source anchors |
| 15. Conflicting skills | `TASK-ROUTING.md`, router skill | One primary workflow; special tools only as needed |
| 16. Operating principle | `CORE.md` | Keep simplicity, high quality, safety and cost optimization |

**Not retained verbatim:** your previous requirement to perform a skill/repository sweep at the start of every session. That conflicts with your token goals, so the new design checks only relevant metadata and defers deeper discovery. Some full external plugins are also not forced on every task because their hooks, workflows and compatibility differ by platform.

**New:** distinct UI quality rubric, external project knowledge map, Windows multi-platform setup, dormant/approval skill states, clear cloud-access limitations, and measurable quality/cost acceptance tests.
