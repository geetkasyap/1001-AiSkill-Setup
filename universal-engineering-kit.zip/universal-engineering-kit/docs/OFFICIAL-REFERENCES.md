# Platform documentation reference (checked 2026-11-17)

- GitHub Copilot App customization: https://docs.github.com/en/copilot/how-tos/github-copilot-app/customize-github-copilot-app
- Copilot CLI global instructions: https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-custom-instructions
- Copilot CLI personal skills: https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-skills
- Codex global instruction discovery: https://learn.chatgpt.com/docs/agent-configuration/agents-md
- Codex skills discovery: https://learn.chatgpt.com/docs/build-skills
- Codex CLI permission controls: https://learn.chatgpt.com/docs/cli
- Antigravity global rules: https://antigravity.google/docs/rules/
- Antigravity skills, App/CLI: https://antigravity.google/docs/skills
- Claude Code settings: https://code.claude.com/docs/en/settings

Paths may differ by product version or policies; if an app does not discover a file, check the current product's Customizations/Rules/Skills UI before creating duplicates elsewhere.
