# Windows setup guide — Copilot App, Codex App/CLI and AGY App/CLI

## 0. Important prerequisites

- This configuration was authored for your Windows workstation. It respects `CODEX_HOME` and `COPILOT_HOME` if set, while other paths use the normal user profile. It does **not** connect to or modify your laptop remotely.
- Review `docs/SECURITY-AND-LIMITATIONS.md` and obtain organizational approval before using any third-party extensions on a company/client machine.
- Use your normal Windows account. Administrator elevation is **not required** to create these per-user files, assuming company policies permit them.
- Do **not** disable PowerShell execution policies, antivirus or company security controls to run this installer.
- This kit installs **only its own files and one instruction-only routing skill**. It does not download any third-party skills, package managers, MCP servers, hooks, recorders, proxies or dependencies.

## 1. Unzip and preview

Extract `universal-engineering-kit.zip` to a folder you control. In PowerShell, change to the extracted folder, for example:

```powershell
cd "$HOME\Downloads\universal-engineering-kit"
.\setup\Install-UniversalEngineering.ps1
```

The first command above is an example path, not a prerequisite. The script prints all **planned** file copies and does not change any file unless `-Apply` is supplied.

If the destinations look correct and your policies allow it:

```powershell
.\setup\Install-UniversalEngineering.ps1 -Apply
```

Files already present with different content are **skipped**, not overwritten. Review conflicting files and merge manually. If you have intentionally decided to replace the contents and want timestamped backups:

```powershell
.\setup\Install-UniversalEngineering.ps1 -Apply -ReplaceExisting
```

**Caution:** replacing global instructions can remove customized guidance from those files. Backups are created, but manual merging is safer when your existing global files include useful rules. No repositories are edited by the script.

To inspect currently discoverable personal skill names without reading every skill body, run `.\setup\Audit-SkillDiscovery.ps1` (read-only).

To check files without changing anything:

```powershell
.\setup\Test-UniversalEngineering.ps1
```

The installed reference copy is at `%USERPROFILE%\AI-Engineering\` (`$HOME\AI-Engineering` in PowerShell). The extracted package's `CORE.md` is the master source for future reruns; edit that source and rerun setup when updating the policy. Keep your extracted kit somewhere durable.

## 2. What each application reads

| Platform | Global instructions/rules | Skill directory for router | Setup notes |
|---|---|---|---|
| **GitHub Copilot App** | App Settings > Sessions > App instructions | Skills in Copilot CLI/repository are made available in the App | Set App instructions manually; avoid duplicating existing policy |
| **GitHub Copilot CLI** (optional) | `%USERPROFILE%\.copilot\copilot-instructions.md` | `%USERPROFILE%\.agents\skills\engineering-workflow-router` | Restart or `/skills reload` after installation |
| **Codex App + CLI** | `%USERPROFILE%\.codex\AGENTS.md` | `%USERPROFILE%\.agents\skills\engineering-workflow-router` | Start a fresh session; Codex App and CLI behavior should be checked in each surface |
| **AGY App + CLI** | `%USERPROFILE%\.gemini\AGENTS.md` | `%USERPROFILE%\.gemini\config\skills\engineering-workflow-router` | Current shared path; restart/reload skills as appropriate |
| **Claude Code** (optional) | `%USERPROFILE%\.claude\CLAUDE.md` | `%USERPROFILE%\.claude\skills\engineering-workflow-router` | Use installer with `-IncludeClaude` |

**AGY clarification:** `agy` is the Google Antigravity CLI. Current Antigravity documentation says its App and CLI can share the global `~/.gemini/config/skills` directory; the CLI also recognizes certain legacy/directories such as `~/.gemini/antigravity-cli/skills`. Use the current unified path first.

## 3. GitHub Copilot App configuration (required manual step)

1. Open GitHub Copilot App > **Settings** > **Sessions** > **App instructions**.
2. Inspect existing content. If your global instruction policy is not already present, paste the contents of `CORE.md` or merge the non-duplicate rules. Save.
3. Open **Customize** > **Skills** and confirm `engineering-workflow-router` is visible via Copilot's CLI/personal skill configuration (if available in your App version).
4. Run the read-only check prompt from `examples/STARTER-PROMPTS.md`. If the skill is not available, consult App's current Customize UI rather than blindly installing duplicate copies.

**GitHub Copilot App ≠ GitHub Copilot CLI.** Their skill ecosystems overlap, but App instructions are configured in the App settings. A local per-user Copilot CLI policy file should not be assumed to control the App's global instructions.

## 4. Codex App and CLI

1. Verify `%USERPROFILE%\.codex\AGENTS.md` contains the policy.
2. Verify `%USERPROFILE%\.agents\skills\engineering-workflow-router\SKILL.md` exists.
3. Open Codex App or run `codex` in a project. Start a new session and ask the read-only prompt from `examples/STARTER-PROMPTS.md`.
4. For complex requests, expect a plan and an approval request before implementation; for small scoped fixes, expect direct focused work.
5. Use platform permission controls and sandbox settings for real enforcement. The text policy does not override user/environment permissions.

If a skill is not shown in the Codex App, check whether your app version refreshes personal skills from `~/.agents/skills`; restart and consult current Skills settings. Some versions have had discovery bugs; do not silently copy to arbitrary undocumented locations.

## 5. Google Antigravity (AGY) App and CLI

1. Verify `%USERPROFILE%\.gemini\AGENTS.md` and `%USERPROFILE%\.gemini\config\skills\engineering-workflow-router\SKILL.md`.
2. In AGY App/IDE: open **Customizations** > **Rules/Skills** and inspect the global rule and skill discovery. Avoid adding duplicate global rules if already loaded.
3. In AGY CLI: start a new `agy` session and inspect the skills. If your version supports `/skills reload`, use it after changes; otherwise restart.
4. AGY has separate rules (always active) and skills (progressively selected). This kit deliberately uses both layers.

## 6. Optional Claude Code

To create additional Claude Code copies, after reviewing existing files:

```powershell
.\setup\Install-UniversalEngineering.ps1 -Apply -IncludeClaude
.\setup\Test-UniversalEngineering.ps1 -IncludeClaude
```

Do not install a second memory plugin simply because it is listed in `SKILL-REGISTRY.md`.

## 7. Optional local project knowledge (consent required)

Project knowledge stays **outside Git** and is never auto-created. For a known project and a unique ID:

```powershell
.\setup\Initialize-ProjectKnowledge.ps1 -ProjectPath 'C:\Dev\MyProject' -ProjectId 'myproject'
# Preview first. Only if you approve:
.\setup\Initialize-ProjectKnowledge.ps1 -ProjectPath 'C:\Dev\MyProject' -ProjectId 'myproject' -Apply
```

This initializes blank templates only and registers the approved repository-to-knowledge-directory mapping in `~/AI-Engineering/PROJECT-INDEX.md`. It does not scan source or capture session history. To use a particular outside-Git folder instead of the default:

```powershell
.\setup\Initialize-ProjectKnowledge.ps1 -ProjectPath 'C:\Dev\MyProject' -ProjectId 'myproject' -KnowledgeDirectory 'D:\AI-Knowledge\myproject' -Apply
```

Keep separate knowledge roots for personal versus client work when policies require. If a task is completed, the agent must **ask before recording useful project findings**, even if a knowledge folder already exists.

## 8. Installing your additional 29 repositories

No mass installation is done by this kit. Start with `docs/THIRD-PARTY-SKILLS.md`. For each desired repo: inspect the official README, verify genuine skill paths and dependencies, review instructions/scripts/permissions/license, then manually install the selected individual skill into the supported personal skill folder for the relevant host. For frameworks, tools and plugin marketplaces, follow their own instructions only after explicit approval. The catalog is **not** executable installation code.

## 9. Acceptance test

Try one simple task, one cross-layer planning task, and one UI concept. The observable goals are:
- Simple tasks use a minimal investigation and targeted validation without activating multiple unrelated skills.
- Complex tasks return a plan, risks and verification strategy **before code changes**.
- UI tasks prioritize existing design system and low-friction interaction while avoiding generic visual output.
- No project knowledge, graph, recorder or external proxy is created/started without your request/approval.

For repeatable measurements see `docs/COST-AND-QUALITY-TESTS.md`.

## 10. Updating registry and router skill

`SKILL-REGISTRY.md` and `skills/engineering-workflow-router/references/skill-registry.md` are identical in this bundle. If you edit the main registry, copy it into the skill's `references` folder before deploying so the skill sees the same activation rules. Rerun `-Apply -ReplaceExisting` after reviewing any backups.

## 11. Source documentation

See `docs/OFFICIAL-REFERENCES.md`; check current platform documentation when upgrading app versions.
