# Evaluate quality and token savings — without gaming the result

Compare the same agent/model and the same tasks **with and without** the new policy, using equivalent clean starting states. Don't claim savings without recording observations.

| Scenario | Correctness requirement | Economy requirement | Skill expectation |
|---|---|---|---|
| Tiny validation bug | Correct changed behavior, no regression | Narrow search/diff, focused test | No unrelated skill or full architecture scan |
| Angular + .NET API feature | Accurate paths/contracts, correct acceptance checks | Reuse existing patterns and short plan | Complex plan first; relevant backend/frontend workflow only |
| Opaque library behavior | Evidence-backed root cause or a stated unknown | No blind speculative edits | REA only if normal source inspection insufficient |
| Existing dashboard UI update | Consistent with existing system, good task flow, accessible | No full redesign unless requested | One primary UI authority; optional targeted reviewer |
| New application plan | Clear scope, options, risks and gated milestones | Avoid duplicate BMAD/GSD/Superpowers plans | Suggest one framework and ask approval |

Record per run: model and effort, tool calls, input/output tokens **if exposed**, elapsed time, tests actually executed, edits/files changed, defects found, rework count, and user judgment of quality. Do not invent token counters that aren't exposed by an agent.

A win is a *correct, verified outcome with lower end-to-end cost*. A one-pass short response that causes retries is not a win. Treat vendor compression/skill benchmark percentages as claims to evaluate rather than guaranteed outcomes.
